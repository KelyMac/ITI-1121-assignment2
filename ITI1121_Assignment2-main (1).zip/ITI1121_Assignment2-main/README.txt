Student name: Kuan-Yu Chang
Student number: 300201058
Section: C

Student name: Jiayi Ma
Student number: 300263220
Section: C

This archive contains the 13 files of the Assignment 2, that is, this file (README.txt),
plus the files Car.java, ParkingLot.java, Util.java, CarType.java, LinkedQueue.java, Queue.java, RandomGenerator.java, 
Rational.java, Simulator.java, Spot.java, TriangularDistribution.java, StudentInfo.java.
